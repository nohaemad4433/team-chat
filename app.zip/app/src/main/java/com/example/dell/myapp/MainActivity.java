package com.example.dell.myapp;

import android.content.DialogInterface;
import android.content.Intent;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
      /*  setContentView(R.layout.activity_main);
        AlertDialog dialog=new AlertDialog.Builder(this).create();
        final EditText et=new EditText(this);
        dialog.setTitle("Enter your name");
        dialog.setView(et);
        dialog.setButton(DialogInterface.BUTTON_POSITIVE, "OK", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                String name =et.getText().toString();
                if(!TextUtils.isEmpty(name))
                {
                    Intent I=new Intent(MainActivity.this,ChatRoom.class);
                    I.putExtra("Name",name);
                    startActivity(I);
                }else{
                    Toast.makeText(MainActivity.this,"Enter your name",Toast.LENGTH_SHORT).show();
                }
            }
        });
        dialog.show();  */
    }
}
